package com.example.cardrechargeapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardRechargeApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(CardRechargeApiApplication.class, args);
    }

}
