package com.yintech.cloud.service.entity.dto;

import com.yintech.commons.request.BasePage;
import lombok.Data;

/**
 * @author ming.li1@yintech.cn
 * @version 1.0-SNAPSHOT
 * @description
 * @Company: yintech
 * @date 2022/2/18 3:26 下午
 */
@Data
public class QueryDTO extends BasePage {
}
